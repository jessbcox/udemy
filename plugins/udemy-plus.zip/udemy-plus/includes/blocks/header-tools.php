<?php

function up_header_tools_render_cb($atts) {
  $user = wp_get_current_user();
  $name = $user->exists() ? $user->user_login : __("Sign in","udemy-plus");
  $openClass = $user->exists() ? '' : 'open-modal';

  ob_start();
  ?>
  <div class="wp-block-udemy-plus-header-tools">
    <?php
    if ($atts['showAuth']) {
      ?>
      <a class="signin-link <?php echo $openClass; ?>" <?php echo (!$user->exists() ? 'href="#"' : ''); ?>>
        <div class="signin-icon">
          <i class="bi bi-person-circle"></i>
        </div>
        <div class="signin-text">
          <small>Hello, <?php echo $name; ?></small>
        </div>
      </a>
      <?php
    }
    ?>
  </div>
  <?php

  $output = ob_get_contents();
  ob_end_clean();

  return $output;
}